# import inspect
# import coreapps.controllers.ev_database as database
# lista =[]
# for name,obj in inspect.getmembers(database):
#     if inspect.isclass(obj):
#         lista.append(obj)
#         print (str(obj))
# 
# a = lista[0].inherit
# 
# print (a)