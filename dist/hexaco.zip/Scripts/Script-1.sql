SELECT idpeserta, idtipesoal, "No Tes", "Tanggal Tes", "Nama Kandidat", "Jenis Kelamin", "Tanggal Lahir", "Pendidikan Terakhir", "Jurusan Pendidikan", Kota, "Perusahaan / Instansi", "Posisi / Jabatan"
FROM "Rincian Data Peserta"
WHERE idpeserta="" or "Tanggal Tes" between 2019/04/15  and 2019/05/14
