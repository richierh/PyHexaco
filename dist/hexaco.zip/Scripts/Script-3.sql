select Dimensi,"Median Laki Laki"
from "Referensi Dimensi"