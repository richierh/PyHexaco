DELETE FROM Input_Data_Jawaban_Peserta
WHERE idpeserta=8
